"""Entry point for our twitoff flask app"""

from app import create_app

# This is a global variable
application = create_app()

if __name__ == '__main__':
    print('__file__={0:<35} | __name__={1:<20} | __package__={2:<20}'.format(__file__,__name__,str(__package__)))
    application.run(debug=True)
